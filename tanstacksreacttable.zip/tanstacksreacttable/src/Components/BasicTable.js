
import {useReactTable,
         getCoreRowModel,
         flexRender,
         getPaginationRowModel,
        getSortedRowModel,
        getFilteredRowModel,} from '@tanstack/react-table'
import mdata from './Data.json'
import { useMemo } from 'react'
import {DateTime} from 'luxon'
import { useState } from 'react'

export default function BasicTable() {
    // {"id":1,
    // "first_name":"Nikolaos"
    // ,"date_of_birth":"2023-08-18 02:14:22",
    // "email":"nsimson0@php.net"
    // ,"gender":"Male",
    // "ip_address":"244.135.88.220"}

const data = useMemo(() => mdata, [])

/** @type import('@tanstack/react-table').columnDef<any>*/
const columns = [
    {
        header : 'ID',
        accessorKey : 'id'
    },
    { 
        header: 'Name',
        accessorFn : row => `${row.first_name} ${row.lats_name}`,
    } ,
    // {
    //     header : 'Full Name',
    //     columns : [
    //         {
    //             header : 'First Name',
    //             accessorKey : 'first_name'
    //         },
    //         {
    //             header : 'Last Name',
    //             accessorKey : 'lats_name'
    //         },
    //     ]
    // },
    {
        header : 'DOB',
        accessorKey : 'date_of_birth',
        cell: info =>
          DateTime.fromISO(info.getValue()).
          toLocaleString(DateTime.DATE_MED),
    },
    {
        header : 'E-mail',
        accessorKey : 'email'
    },
    {
        header : 'Gender',
        accessorKey : 'gender'
    },
    {
        header : 'IP',
        accessorKey : 'ip_address'
    }
]

const [sorting , setSorting] = useState([])
const [filtering , setFiltering] = useState('')
 

 const table = useReactTable({
    data, 
    columns,
    getCoreRowModel : getCoreRowModel(),
    getPaginationRowModel : getPaginationRowModel(),
    getSortedRowModel : getSortedRowModel(),
    getFilteredRowModel : getFilteredRowModel(),
    state:{
        sorting : sorting,
        globalFilter : filtering

    },
    onSortingChange : setSorting,
    onGlobalFilterChange : setFiltering,
 })
  return (
    <div>
        <input 
        type='text' 
        value={filtering} 
        onChange={(e) => 
        setFiltering(e.target.value)}
         />
        <table>
            <thead>
            {table.getHeaderGroups().map(headerGroup => (
                <tr key={headerGroup.id}>
                    {headerGroup.headers.map(header => (
                        <th key={header.id} onClick={header.column.getToggleSortingHandler()}>
                            {header.isPlaceholder ? null :( 
                            <div>
                                {flexRender(
                                header.column.columnDef.
                                header,
                                header.getContext()
                                )}
                                {
                                    {asc:'🔼', desc:'🔽'}
                                    [
                                        header.column.getIsSorted() ?? null
                                    ]
                                }
                                 </div>
                    )}
                        </th>
                    ) )}
                </tr>
            ))}
        </thead>
            <tbody>
                {table.getRowModel().rows.map(row =>( 
                    <tr key={row.id}>
                        {row.getVisibleCells().map(cell => (
                            <td>
                                {flexRender(cell.column.columnDef.cell,cell.
                                    getContext())}
                            </td>
                        ))}
                    </tr>
                ))}               
            </tbody>
        </table>
        <div>
            <button onClick={() =>table.setPageIndex(0)}>First Page</button>
            <button disabled={!table.getCanPreviousPage()} onClick={() =>table.previousPage()}>Previous Page</button>
            <button disabled={!table.getCanNextPage()} onClick={() =>table.nextPage()}>Next Page</button>
            <button onClick={() =>table.setPageIndex(table.getPageCount()-1)}>Last Page</button>
        </div>
       
    </div>
  )
}
