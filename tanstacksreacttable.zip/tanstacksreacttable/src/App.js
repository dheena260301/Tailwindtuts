import logo from './logo.svg';
import './App.css';
import BasicTable from './Components/BasicTable';

function App() {
  return (
    <div className="App">
      <BasicTable />
    </div>
  );
}

export default App;
