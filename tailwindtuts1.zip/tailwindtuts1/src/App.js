import './App.css';
import Appbar from './Appbar';
import Filters from './Filters';

function App() {
  return (
    <>
    {/* <span className='text-5xl font-bold text-green-500'>Fruit</span>
    <span className='text-4xl font-light'>Shop</span>
    <div>
      <span className='text-stone-500 text-4xl font-display'>Season specials</span>
    </div>
    <div>
      <span className='text-stone-500 text-4xl font-display'>Find us on</span>
    </div> */}
    <Appbar/>
    <Filters/>
    </>
  );
}

export default App;
