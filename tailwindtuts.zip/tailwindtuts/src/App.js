import Items from './components/Items';
import './App.css';
import Appbar from './components/Appbar';
import Filters from './components/Filters';
import ProflileCard from './components/ProflileCard';

function App() {
  return (
    <>
    {/* <span className='text-5xl font-bold text-green-500'>Fruit</span>
    <span className='text-4xl font-light'>Shop</span>
    <div>
      <span className='text-stone-500 text-4xl font-display'>Season specials</span>
    </div>
    <div>
      <span className='text-stone-500 text-4xl font-display'>Find us on</span>
    </div> */}
    <Appbar/>
    <Filters/>
    <Items />
    {/* <ProflileCard /> */}
    </>
  );
}

export default App;
