import React from 'react'
import { Link } from 'react-router-dom'


export default function Products() {
  return (
    
    <div className="min-h-screen flex items-center justify-center bg-gray-100 w-[500px] ">
    <div className="bg-white p-8 rounded-lg shadow-lg">
      <table className="w-[400px] h-[400px]">

        <thead>
          <tr className="text-center bg-blue-800 text-white h-[50px] ">
           <th className="rounded-tl-xl rounded-bl-xl">Name</th> 
           <th className="">Age</th>
           <th className="rounded-br-xl rounded-tr-xl">Role</th>
          </tr>
        </thead>

        <tbody className='text-center'>
         
          <tr className="bg-gray-200  hover:bg-gray-300 mb-5 border-y-8 border-white">
            <td className=" rounded-tl-xl rounded-bl-xl   ">Temitope</td>
            <td className=" ">12</td>
            <td className="rounded-br-xl rounded-tr-xl  ">Accountant</td>
          </tr>
       
         
          <tr className="bg-gray-100  hover:bg-gray-300 border-y-8 border-white ">
            <td className=" rounded-tl-xl rounded-bl-xl  ">Temitope</td>
            <td className=" ">12</td>
            <td className="rounded-br-xl rounded-tr-xl ">Accountant</td>
          </tr>
          
          
          <tr className="bg-gray-200  hover:bg-gray-300 border-y-8 border-white p-10 ">
            <td className=" rounded-tl-xl rounded-bl-xl  ">Temitope</td>
            <td className=" ">12</td>
            <td className="rounded-br-xl rounded-tr-xl  ">Accountant</td>
          </tr>
         
          
          <tr className="bg-gray-100  hover:bg-gray-300 border-y-8 border-white ">
            <td className=" rounded-tl-2xl rounded-bl-2xl  ">Temitope</td>
            <td className=" ">12</td>
            <td className="rounded-br-2xl rounded-tr-2xl   ">Accountant</td>
          </tr>

          <tr className="bg-gray-200  hover:bg-gray-300 border-y-8 border-white ">
            <td className=" rounded-tl-2xl rounded-bl-2xl  ">Temitope</td>
            <td className=" ">12</td>
            <td className="rounded-br-2xl rounded-tr-2xl   ">Accountant</td>
          </tr>

          <tr className="bg-gray-100  hover:bg-gray-300 border-y-8 border-white ">
            <td className=" rounded-tl-2xl rounded-bl-2xl  ">Temitope</td>
            <td className=" ">12</td>
            <td className="rounded-br-2xl rounded-tr-2xl   ">Accountant</td>
          </tr>

          <tr className="bg-gray-200  hover:bg-gray-300 border-y-8 border-white ">
            <td className=" rounded-tl-2xl rounded-bl-2xl  ">Temitope</td>
            <td className=" ">12</td>
            <td className="rounded-br-2xl rounded-tr-2xl   ">Accountant</td>
          </tr>
          
         

        </tbody>
      </table>
    </div>
  </div>


  )
}
