import React from 'react'
import Layout from './Components/Shared/Layout';
import { Route, BrowserRouter as Router, Routes } from 'react-router-dom'
import Dashboard from './Components/Dashboard';
import Products from './Components/Products';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Dashboard />} />
          <Route path='products' element={<Products />} />
        </Route>
        <Route>
          <Route path='login' element={<div>this is login page</div>} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;
